# Granite Website Project

Simple static website themed around granite.

## Features
- Modern dark UI
- Responsive grid layout
- Simple structure (HTML + CSS)

## How to Use
1. Download ZIP
2. Extract
3. Open index.html in browser

## Author
Gudhal Production
